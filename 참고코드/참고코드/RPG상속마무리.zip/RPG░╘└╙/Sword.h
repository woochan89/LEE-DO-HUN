#pragma once
#include"Weapon.h"
class Sword : public Weapon
{
public:
	Sword();
	void Draw(int h);
	void Show();
	~Sword();
};

