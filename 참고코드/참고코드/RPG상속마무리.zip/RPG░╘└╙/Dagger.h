#pragma once
#include "Weapon.h"
class Dagger : public Weapon
{
public:
	Dagger();
	void Draw(int h);
	void Show();
	~Dagger();
};

