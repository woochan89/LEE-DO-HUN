#pragma once
#include"Weapon.h"
class Wand : public Weapon
{
public:
	Wand();
	void Draw(int h);
	void Show();
	~Wand();
};

