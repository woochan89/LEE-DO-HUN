#pragma once
#include"Weapon.h"
class Hammer : public Weapon
{
public:
	Hammer();
	void Draw(int h);
	void Show();
	~Hammer();
};

