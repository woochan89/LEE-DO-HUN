#include"Mecro.h"
#include"Game.h"

void main()
{
	Game GameManager;
	
	GameManager.MainPage();
}